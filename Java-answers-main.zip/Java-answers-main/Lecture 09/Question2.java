In the below code
double x = 2.3d;
String name = "Bhargo";
byte[] buffer = new byte[1024];
x is called a variable
name is called a reference
buffer is called a reference
A variable can be compared to a cup, which holds the value of the primitive date type.
A reference can be compared to a cup, which holds the address of the object it points to.

When not initialized, the default value of a variable is 0 for numeric primitive types and false for boolean types.
When not initialized, the default value of a reference is null. If a reference has a null value, it means that the reference does not refers (points) to any object.
Select all the correct statements that apply to the below code.
String name = null;
int age = null;
byte[] buffer = null;
boolean status = null;


Answer 


Statement String name = null; is correct
Statement byte[] buffer = null; is correct