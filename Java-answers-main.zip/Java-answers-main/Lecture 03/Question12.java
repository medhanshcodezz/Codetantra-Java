package q10808;
public class PrintHello {
	public static void main(String[] args) {
		String text1 = "He";
		String text2 = "llo";
		String text3 = text1 + text2;
		System.out.println("text3 = " + text3);
	}
}