package q10801;
public class PrintHello {
	public static void main(String[] args) {
		String text1 = "He";
		String text2 = "llo";
		String text3 = text1 + text2;
		String text4 = ", I am learning Java";
		String text5 = text3 + text4; 
		System.out.println("text5 = " + text5);
	}
}