package q10799;
/**
 * This is a sample Java Doc comment
 * @author James
 */
public class TestComments {
	public static void main(String[] args) {
		/* this is an example for standard comment which can span across multiple lines */
		// this is an end of line comment
		System.out.println("This is a simple example on java comment lines");
	}
}