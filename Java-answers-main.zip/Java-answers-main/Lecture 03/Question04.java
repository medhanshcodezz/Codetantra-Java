package q10800;
public class PrintHello {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}