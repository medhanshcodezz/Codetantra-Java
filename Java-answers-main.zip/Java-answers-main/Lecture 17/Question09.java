Write a class PrintThreeTimes with a main method. The program should print Thames three times.

Fill the missing code so that it produces the desired output.

Note: Please don't change the package name.

package q10890;
public class PrintThreeTimes {
	public static void main(String[] args) {
		int i = 0;
		while (i<3 ) {
			System.out.println("Thames");
			i ++ ;
		}
	}
}