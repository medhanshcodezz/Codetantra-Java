Write a class PrintFiveTimes with a main method. The program should print Ganga five times.

Fill the missing code in the below program so that it produces the desired output.

Note: Please don't change the package name.

package q10889;
public class PrintFiveTimes {
	public static void main(String[] args) {
		int i = 0;
		while (i <5 ) { // complete the condition here 
			System.out.println("Ganga");//write the text to be printed here
			i = i + 1;
		}
	}
}

