Select all the correct statements from the given options.

Answer 

int x = 07_08_09; is a valid usage of Underscore
int x = 0xA_B;
int x = 1_____________0;