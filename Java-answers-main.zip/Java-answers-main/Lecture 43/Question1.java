In Java, when we do not want a class to ever have subclasses, we declare that class as final.

In Java we have many final classes. For example, like the String and all the wrapper classes like Integer, Float etc.


Answer

We declare a class as final, when we do not want someone to change its implementation by subclassing 