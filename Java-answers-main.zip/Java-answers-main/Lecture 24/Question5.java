A constructor must be written inside the class body (i.e. inside the open brace { and the closing brace } of the class body).

Identify the errors and correct them.


package q11161;
public class Student {
	private String id;
	private String name;
	private int age;
	private char gender;
	


	public Student(String name, String rollNo, int age, char gender) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
	}


    