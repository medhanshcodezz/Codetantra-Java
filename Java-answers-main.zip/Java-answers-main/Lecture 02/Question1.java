Click on the below Live Demo button to learn the steps involved in writing and executing a Java program.



After learning from the Live Demo, select all correct statements given below:

Answer 

The Java compiler uses the Java source file and generates file with .class extension.
The file with .class extension is called as Java class file.
The Java class file contains the Java bytecode, which is executed by the Java Virtual Machine (JVM).