package q10751;
public class Student {

}