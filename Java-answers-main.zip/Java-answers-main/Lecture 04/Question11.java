package q10793;
public class CommandLineArgumentDemo {
	public static void main(String[] args) {
		//Write the code fragment in the below println(     ) method to print only the second argument
		System.out.println( args[1] );
	}
}