Fix the text in the main method using escape characters to produce the below output.

There are double-quotes around "Red"

package q11148;
public class EscapeSequence {
	public static void main(String[] args) {
		String text1 = "There are double-quotes around \"Red\"";
		System.out.println(text1);
	}
}

