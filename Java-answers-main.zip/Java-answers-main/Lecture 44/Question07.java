Given
public class Main {
          public static void main(String args[]) {
              StringBuilder sb = new StringBuilder("Hi! Good Morning.");
           
          }
}
Write an expression that refers to the letter M in the string referred to by sb. Choose the correct option from the below.


Answer

sb.charAt(9)