public class StringBuilderDemo {
	public static void main(String args[]) {
        String s = "Hello";
        s.concat("World");
        System.out.println(s);  
	}
}
What will be the output for the above program. Choose the correct option form the below.



Answer


Hello