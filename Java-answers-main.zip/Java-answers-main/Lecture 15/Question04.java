Create a class PrintBiggerNumber with a public method checkNumbers that takes two parameters firstNo and secondNo are of type int and returns true if firstNo is greater than secondNo. The return type of checkNumbers should be boolean.

These are examples for understanding:
Cmd Args : 65 32
true
Cmd Args : 4 100
false


Note: Please don't change the package name.

package q10865;

public class PrintBiggerNumber {
	/**
	 * Compare if firstNo is greater than secondNo are not
	 * 
	 * 
	 * @return result
	 * 
	 */ 
	
	public boolean checkNumbers(int firstNo, int secondNo) {
		
		//Write your code here
		//write your code here
		
		if(firstNo >secondNo){
			
			return true;
		}	
			else{
				
				return false;
				
			}
			
			
		
		
	}
}