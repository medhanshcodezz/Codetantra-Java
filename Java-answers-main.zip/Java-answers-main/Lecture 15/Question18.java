Given:
String[] elements = { "abc", "xyz", "pqr" };
String first = (elements.length > 0) ? elements[0] : null;
What is the result ?



Answer 

The variable 'first' is set to "abc"