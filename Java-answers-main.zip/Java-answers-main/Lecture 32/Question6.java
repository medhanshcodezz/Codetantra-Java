Given :
public static void main(String[] args) {
     Integer i = new Integer(1) + new Integer(2);
      switch(i) {
          case 3: 
              System.out.println("three");
              break;
          default: 
              System.out.println("other");
              break;
     }
 }
What is the result?

three

