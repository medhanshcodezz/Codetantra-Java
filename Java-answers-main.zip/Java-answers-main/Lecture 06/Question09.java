package q10774;
public class ShortDemo {
	public static void main(String[] args) {
		short mangos = 3;
		short bananas = 4;
		short fruits =(short) (mangos + bananas);
		System.out.println("fruits = " + fruits);// should print 7
	}
}