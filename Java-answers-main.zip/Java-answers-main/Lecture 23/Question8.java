Identify the errors in below code and correct them.

Note: Please don't change the package name.'


package q11217;
public class Student {
	private String id;
	private String name;
	private int age;
	private char gender;
}

