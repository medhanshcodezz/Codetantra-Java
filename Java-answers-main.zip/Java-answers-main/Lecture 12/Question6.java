Java supports the below compound assignment operators
+= -= *= /= %= &= ^= |= <<= >>= >>>=

Usage:

int x = 3, y = 4, z = 0;

z += x; // is same as writing z = z + x;
z -= y; // is same as writing z = z - y;Select all the valid statements from the below code.
int x = 2, y = 4, z = 5, value1 = 0, value2 = 0, value3 = 0;

value1 *= x;

value2 = x += 2 * y;

y *= z;

value3 -= 1;



Answer 

value1 = 0

y *= z; results in y's value being changed to 20

value3 = -1