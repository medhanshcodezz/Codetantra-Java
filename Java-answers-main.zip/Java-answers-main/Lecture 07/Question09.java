Select all the correct statements.


Answer 


double d = 7.; is a valid statement
double d = .7; is a valid statement
double d = 7; is a valid statement
double d = 1e1; is a valid statement