Write a class StringCompare with a main method. The method receives one command line argument. Print true if the argument ends with the suffix ed, else print false.

For Example:
Cmd Args : prefixed
true


package q11168;


public class StringCompare {
	
	public static void main(String[] args) {
		
		String str1 = args[0];
		
		
		
		System.out.println(str1.endsWith("ed"));
		
		
		
		
		
		
	}
}

