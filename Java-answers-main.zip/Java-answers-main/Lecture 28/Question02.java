Create a class TestStringMethods with a main method. The method receives one command line argument. Calculate the length of the argument and print the output.

For Example:
Cmd Args : Independance
12

package q11152;


public class TestStringMethods {
	
	public static void main(String[] args) {
		
		String str = args[0];
		
		System.out.println(str.length());
		
		
		
	}
	
	
	
}

